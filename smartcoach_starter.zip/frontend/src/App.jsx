
import { useState } from 'react';
import axios from 'axios';

function App() {
  const [file, setFile] = useState(null);
  const [result, setResult] = useState("");

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append("file", file);
    const res = await axios.post("http://localhost:8000/analyze-resume", formData);
    setResult(JSON.stringify(res.data));
  };

  return (
    <div>
      <h1>SmartCoach Resume Analyzer</h1>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={handleUpload}>Analyze Resume</button>
      <p>{result}</p>
    </div>
  );
}

export default App;
