
# SmartCoach

An AI-powered interview coaching SaaS with resume analysis and job matching.

## Running the Project

### Backend (FastAPI)
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### Frontend (React + Vite)
```bash
cd frontend
npm install
npm run dev
```

### Visit:
- Frontend: http://localhost:5173
- Backend Test: http://localhost:8000/health
```
